import React from 'react';
import Header from './components/Header';
import Section from './components/Section';
import Footer from './components/Footer';

function App() {
  return (
      <div>
        <Header />
        <Section
            title="Fasi e Modelli di Gestione di un Ciclo di Sviluppo"
            content="Il ciclo di sviluppo del software segue diverse fasi strutturate, fondamentali per garantire un prodotto finale funzionale e di qualità. Tra i principali modelli utilizzati abbiamo il modello a cascata, il modello incrementale e lo sviluppo agile. Questi modelli si adattano a diversi contesti e progetti, garantendo flessibilità e controllo durante le fasi di progettazione, sviluppo, testing e manutenzione del software."
        />
        <Section
            title="Raccolta e Analisi dei Requisiti"
            content="La fase di raccolta dei requisiti rappresenta un passaggio cruciale nello sviluppo di un software. Utilizziamo tecniche di esplorazione e diagrammi dei casi d'uso per comprendere e definire le necessità del cliente. Questo passaggio consente di allineare le aspettative con le funzionalità che verranno effettivamente implementate nel prodotto finale."
        />
        <Section
            title="Documentazione e Testing del Software"
            content="La documentazione del software è essenziale per garantire che ogni fase del ciclo di sviluppo sia tracciata e comprensibile. Abbiamo trattato come redigere documenti tecnici utili per lo sviluppo e la manutenzione futura del software, oltre a cenni sul testing per validare il corretto funzionamento dell'applicazione in fase di sviluppo."
        />
        <Section
            title="Linguaggi di Programmazione Lato Client"
            content="Durante il corso abbiamo approfondito l'uso di JavaScript per la gestione degli eventi locali all'interno delle pagine web. Successivamente, abbiamo esplorato il framework React per la creazione di single page applications, utilizzando i componenti e il modello di gestione dello stato. Abbiamo anche appreso come utilizzare Bootstrap per la progettazione di interfacce web responsive e professionali."
        />
        <Section
            title="Progetto Finale"
            content="Il progetto finale prevede la creazione di un sito web che integri tutte le conoscenze acquisite durante l'anno, inclusi React, Bootstrap e JavaScript. L'obiettivo è sintetizzare i concetti appresi e dimostrare la comprensione pratica e teorica degli strumenti utilizzati nello sviluppo front-end."
        />
        <Footer />
      </div>
  );
}

export default App;
