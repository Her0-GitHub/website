import React from 'react';

function Header() {
    return (
        <header className="bg-dark text-white text-center py-5">
            <h1>Tecnologie e Progettazione di Sistemi Informatici e di Telecomunicazioni</h1>
            <p>Benvenuti nel sito che raccoglie i principali argomenti trattati nel corso dell'anno scolastico 2023/2024.</p>
        </header>
    );
}

export default Header;
